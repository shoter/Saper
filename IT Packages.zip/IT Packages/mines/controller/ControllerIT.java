/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mines.controller;

import java.awt.Component;
import java.awt.event.MouseEvent;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author D
 */
public class ControllerIT {
    
    private class MouseEventTest extends MouseEvent{
        public int x;
        public int y;
        public int button;
        
        public MouseEventTest(Component cmpnt, int i, long l, int i1, int i2, int i3, int i4, boolean bln, int i5) {
            super(cmpnt, i, l, i1, i2, i3, i4, bln, i5);
        }
        
        @Override
        public int getX(){
            return x;
        }
        @Override
        public int getY(){
            return x;
        }
        @Override
        public int getButton(){
            return button;
        }
    }
    
    public ControllerIT() {
    }

    @Test
    public void testSomeMethod() {
    }
    
}
